package ch.zhaw.infm.springboottemplate.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ch.zhaw.infm.springboottemplate.entities.Sun;
import ch.zhaw.infm.springboottemplate.repositories.SunRepository;

/**
 * 
 * REST-Controller für die Ressource World
 * 
 */
@RestController
public class SunRestController {
	@Autowired
	private SunRepository sunRepository;

	@RequestMapping(value = "/infmapi/v1/suns", method = RequestMethod.GET)

	public ResponseEntity<List<Sun>> getWorlds() {
		// Alle Karten aus dem Repository laden und der cards-Variable zuweisen
		List<Sun> suns = sunRepository.findAllByOrderByName();
		// Wenn die Liste Einträge enthält...
		if (suns != null && !suns.isEmpty()) {
			// ... dann diese als Body zurückgeben
			return new ResponseEntity(suns, HttpStatus.OK);
		} else {
			// ... ansonsten ResourceNotFoundException (404)
			return new ResponseEntity(HttpStatus.NOT_FOUND);

		}

	}

}